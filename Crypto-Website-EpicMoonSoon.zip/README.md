This website can easily be customized for a new meme token crypto project! 

Feel free to use and if you have any issuse let me know.
